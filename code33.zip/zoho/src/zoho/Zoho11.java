package zoho;

public class Zoho11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     String str="WATER";
     
    System.out.println("        "+str.charAt(2));
	System.out.println("       "+str.substring(2,4));
    System.out.println("      "+str.substring(2,5));
    System.out.println("     "+str.substring(2,5)+str.charAt(0));
    System.out.println("    "+str.substring(2,5)+str.substring(0,2));
     
}
}